"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const repair_1 = require("../../../../../modules/repair");
// POST /admin/repairs/:id/custom-parts - Add a custom part
async function POST(req, res) {
    const repairService = req.scope.resolve(repair_1.REPAIR_MODULE);
    const { name, price } = req.body;
    if (!name || price === undefined) {
        res
            .status(400)
            .json({ message: "Name and price are required for custom parts" });
        return;
    }
    const ticket = await repairService.retrieveRepairTicket(req.params.id);
    // Initialize if null somehow, though model sets default []
    const customParts = Array.isArray(ticket.custom_parts)
        ? [...ticket.custom_parts]
        : [];
    const priceInCents = Number(price);
    customParts.push({ name, price: priceInCents });
    // also update parts estimate
    const currentPartsEstimate = typeof ticket.parts_estimate === "object" &&
        ticket.parts_estimate !== null &&
        "value" in ticket.parts_estimate
        ? Number(ticket.parts_estimate.value)
        : Number(ticket.parts_estimate);
    const currentLaborEstimate = typeof ticket.labor_estimate === "object" &&
        ticket.labor_estimate !== null &&
        "value" in ticket.labor_estimate
        ? Number(ticket.labor_estimate.value)
        : Number(ticket.labor_estimate);
    const updatedPartsEstimate = currentPartsEstimate + priceInCents;
    const updatedTicket = await repairService.updateRepairTickets({
        id: req.params.id,
        custom_parts: customParts,
        parts_estimate: updatedPartsEstimate,
        total_estimate: updatedPartsEstimate + currentLaborEstimate,
    });
    res.json({ repair_ticket: updatedTicket });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3JlcGFpcnMvW2lkXS9jdXN0b20tcGFydHMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFNQSxvQkFpREM7QUFwREQsMERBQThEO0FBRTlELDJEQUEyRDtBQUNwRCxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFtRCxFQUNuRCxHQUFtQjtJQUVuQixNQUFNLGFBQWEsR0FBd0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsc0JBQWEsQ0FBQyxDQUFDO0lBQzVFLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsR0FBRyxDQUFDLElBQXVDLENBQUM7SUFFcEUsSUFBSSxDQUFDLElBQUksSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDakMsR0FBRzthQUNBLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDWCxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsOENBQThDLEVBQUUsQ0FBQyxDQUFDO1FBQ3JFLE9BQU87SUFDVCxDQUFDO0lBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxhQUFhLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUV2RSwyREFBMkQ7SUFDM0QsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQ3BELENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQztRQUMxQixDQUFDLENBQUMsRUFBRSxDQUFDO0lBRVAsTUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ25DLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUM7SUFFaEQsNkJBQTZCO0lBQzdCLE1BQU0sb0JBQW9CLEdBQ3hCLE9BQU8sTUFBTSxDQUFDLGNBQWMsS0FBSyxRQUFRO1FBQ3pDLE1BQU0sQ0FBQyxjQUFjLEtBQUssSUFBSTtRQUM5QixPQUFPLElBQUksTUFBTSxDQUFDLGNBQWM7UUFDOUIsQ0FBQyxDQUFDLE1BQU0sQ0FBRSxNQUFNLENBQUMsY0FBc0IsQ0FBQyxLQUFLLENBQUM7UUFDOUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7SUFFcEMsTUFBTSxvQkFBb0IsR0FDeEIsT0FBTyxNQUFNLENBQUMsY0FBYyxLQUFLLFFBQVE7UUFDekMsTUFBTSxDQUFDLGNBQWMsS0FBSyxJQUFJO1FBQzlCLE9BQU8sSUFBSSxNQUFNLENBQUMsY0FBYztRQUM5QixDQUFDLENBQUMsTUFBTSxDQUFFLE1BQU0sQ0FBQyxjQUFzQixDQUFDLEtBQUssQ0FBQztRQUM5QyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUVwQyxNQUFNLG9CQUFvQixHQUFHLG9CQUFvQixHQUFHLFlBQVksQ0FBQztJQUVqRSxNQUFNLGFBQWEsR0FBRyxNQUFNLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQztRQUM1RCxFQUFFLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQ2pCLFlBQVksRUFBRSxXQUFpRDtRQUMvRCxjQUFjLEVBQUUsb0JBQW9CO1FBQ3BDLGNBQWMsRUFBRSxvQkFBb0IsR0FBRyxvQkFBb0I7S0FDNUQsQ0FBQyxDQUFDO0lBRUgsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLGFBQWEsRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFDO0FBQzdDLENBQUMifQ==