"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const repair_1 = require("../../../../../modules/repair");
// POST /admin/repairs/:id/custom-parts - Add a custom part
async function POST(req, res) {
    const repairService = req.scope.resolve(repair_1.REPAIR_MODULE);
    const { name, price } = req.body;
    if (!name || price === undefined) {
        res
            .status(400)
            .json({ message: "Name and price are required for custom parts" });
        return;
    }
    const ticket = await repairService.retrieveRepairTicket(req.params.id);
    // Initialize if null somehow, though model sets default []
    const customParts = Array.isArray(ticket.custom_parts)
        ? [...ticket.custom_parts]
        : [];
    const priceInCents = Math.round(Number(price) * 100);
    customParts.push({ name, price: priceInCents });
    // also update parts estimate
    const currentPartsEstimate = typeof ticket.parts_estimate === "object" &&
        ticket.parts_estimate !== null &&
        "value" in ticket.parts_estimate
        ? Number(ticket.parts_estimate.value)
        : Number(ticket.parts_estimate);
    const currentLaborEstimate = typeof ticket.labor_estimate === "object" &&
        ticket.labor_estimate !== null &&
        "value" in ticket.labor_estimate
        ? Number(ticket.labor_estimate.value)
        : Number(ticket.labor_estimate);
    const updatedPartsEstimate = currentPartsEstimate + priceInCents;
    const updatedTicket = await repairService.updateRepairTickets({
        id: req.params.id,
        custom_parts: customParts,
        parts_estimate: updatedPartsEstimate,
        total_estimate: updatedPartsEstimate + currentLaborEstimate,
    });
    res.json({ repair_ticket: updatedTicket });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3JlcGFpcnMvW2lkXS9jdXN0b20tcGFydHMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFNQSxvQkFpREM7QUFwREQsMERBQThEO0FBRTlELDJEQUEyRDtBQUNwRCxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFtRCxFQUNuRCxHQUFtQjtJQUVuQixNQUFNLGFBQWEsR0FBd0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsc0JBQWEsQ0FBQyxDQUFDO0lBQzVFLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsR0FBRyxDQUFDLElBQXVDLENBQUM7SUFFcEUsSUFBSSxDQUFDLElBQUksSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDakMsR0FBRzthQUNBLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDWCxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsOENBQThDLEVBQUUsQ0FBQyxDQUFDO1FBQ3JFLE9BQU87SUFDVCxDQUFDO0lBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxhQUFhLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUV2RSwyREFBMkQ7SUFDM0QsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQ3BELENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQztRQUMxQixDQUFDLENBQUMsRUFBRSxDQUFDO0lBRVAsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFDckQsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQztJQUVoRCw2QkFBNkI7SUFDN0IsTUFBTSxvQkFBb0IsR0FDeEIsT0FBTyxNQUFNLENBQUMsY0FBYyxLQUFLLFFBQVE7UUFDekMsTUFBTSxDQUFDLGNBQWMsS0FBSyxJQUFJO1FBQzlCLE9BQU8sSUFBSSxNQUFNLENBQUMsY0FBYztRQUM5QixDQUFDLENBQUMsTUFBTSxDQUFFLE1BQU0sQ0FBQyxjQUFzQixDQUFDLEtBQUssQ0FBQztRQUM5QyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUVwQyxNQUFNLG9CQUFvQixHQUN4QixPQUFPLE1BQU0sQ0FBQyxjQUFjLEtBQUssUUFBUTtRQUN6QyxNQUFNLENBQUMsY0FBYyxLQUFLLElBQUk7UUFDOUIsT0FBTyxJQUFJLE1BQU0sQ0FBQyxjQUFjO1FBQzlCLENBQUMsQ0FBQyxNQUFNLENBQUUsTUFBTSxDQUFDLGNBQXNCLENBQUMsS0FBSyxDQUFDO1FBQzlDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBRXBDLE1BQU0sb0JBQW9CLEdBQUcsb0JBQW9CLEdBQUcsWUFBWSxDQUFDO0lBRWpFLE1BQU0sYUFBYSxHQUFHLE1BQU0sYUFBYSxDQUFDLG1CQUFtQixDQUFDO1FBQzVELEVBQUUsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUU7UUFDakIsWUFBWSxFQUFFLFdBQWlEO1FBQy9ELGNBQWMsRUFBRSxvQkFBb0I7UUFDcEMsY0FBYyxFQUFFLG9CQUFvQixHQUFHLG9CQUFvQjtLQUM1RCxDQUFDLENBQUM7SUFFSCxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsYUFBYSxFQUFFLGFBQWEsRUFBRSxDQUFDLENBQUM7QUFDN0MsQ0FBQyJ9