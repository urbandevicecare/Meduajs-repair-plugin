"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rejectRepairCostWorkflow = exports.notifyTechnicianRejectedStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const update_repair_ticket_status_1 = require("./steps/update-repair-ticket-status");
const repair_1 = require("../modules/repair");
const utils_1 = require("@medusajs/framework/utils");
const repair_2 = require("../utils/templates/repair");
exports.notifyTechnicianRejectedStep = (0, workflows_sdk_1.createStep)("notify-technician-rejected", async (input, { container }) => {
    const repairService = container.resolve(repair_1.REPAIR_MODULE);
    const ticket = await repairService.retrieveRepairTicket(input.repair_ticket_id);
    if (ticket.technician_id) {
        let technicianEmail = "";
        const customerModuleService = container.resolve(utils_1.Modules.CUSTOMER);
        try {
            const customer = await customerModuleService.retrieveCustomer(ticket.technician_id);
            if (customer.email)
                technicianEmail = customer.email;
        }
        catch (e) {
            try {
                const userModuleService = container.resolve(utils_1.Modules.USER);
                const user = await userModuleService.retrieveUser(ticket.technician_id);
                if (user.email)
                    technicianEmail = user.email;
            }
            catch (e2) { }
        }
        if (technicianEmail) {
            const [settings] = await repairService.listRepairSettings({});
            if (!settings || settings.email_notifications_enabled) {
                const templateData = {
                    ticket_number: ticket.ticket_number,
                    status: ticket.status,
                    repair_ticket_id: ticket.id,
                    technician_name: ticket.technician_name,
                };
                const template = (0, repair_2.getRepairTemplate)("technician-job-rejected", templateData);
                const notificationModuleService = container.resolve(utils_1.Modules.NOTIFICATION);
                await notificationModuleService.createNotifications({
                    to: technicianEmail,
                    channel: "email",
                    template: "technician-job-rejected",
                    content: {
                        subject: `Repair Job Cancelled: #${ticket.ticket_number}`,
                        html: template.html,
                    },
                    data: {
                        ...templateData,
                        body: template.text,
                    },
                });
            }
        }
    }
    // 3. Delete Zoho Books Estimate if enabled
    const [settings] = await repairService.listRepairSettings({});
    if (settings?.zoho_books_enabled && settings.zoho_client_id) {
        try {
            const logger = container.resolve("logger");
            const { ZohoBooksService } = await import("../services/zoho-books.js");
            const zoho = new ZohoBooksService({
                client_id: settings.zoho_client_id,
                client_secret: settings.zoho_client_secret,
                refresh_token: settings.zoho_refresh_token,
                organization_id: settings.zoho_organization_id,
            }, logger);
            const metadata = ticket.metadata || {};
            if (metadata.zoho_estimate_id) {
                await zoho.deleteEstimate(metadata.zoho_estimate_id);
                logger.info(`[Zoho Books] Deleted estimate ${metadata.zoho_estimate_id} for rejected ticket ${ticket.id}`);
                // clear from metadata
                const newMeta = { ...metadata };
                delete newMeta.zoho_estimate_id;
                await repairService.updateRepairTickets({ id: ticket.id, metadata: newMeta });
            }
        }
        catch (e) {
            container.resolve("logger").error(`[Zoho Books] Failed to delete estimate: ${e.message}`);
        }
    }
    return new workflows_sdk_1.StepResponse(null);
});
exports.rejectRepairCostWorkflow = (0, workflows_sdk_1.createWorkflow)("reject-repair-cost-workflow", function (input) {
    const updatedTicket = (0, update_repair_ticket_status_1.updateRepairTicketStatusStep)({
        repair_ticket_id: input.repair_ticket_id,
        status: "cancelled",
    });
    (0, exports.notifyTechnicianRejectedStep)({ repair_ticket_id: input.repair_ticket_id });
    return new workflows_sdk_1.WorkflowResponse({
        repairTicket: updatedTicket,
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVqZWN0LXJlcGFpci1jb3N0LXdvcmtmbG93LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9yZWplY3QtcmVwYWlyLWNvc3Qtd29ya2Zsb3cudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBSzJDO0FBQzNDLHFGQUFtRjtBQUNuRiw4Q0FBa0Q7QUFFbEQscURBQW9EO0FBQ3BELHNEQUE4RDtBQU1qRCxRQUFBLDRCQUE0QixHQUFHLElBQUEsMEJBQVUsRUFDcEQsNEJBQTRCLEVBQzVCLEtBQUssRUFBRSxLQUFtQyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUMzRCxNQUFNLGFBQWEsR0FBd0IsU0FBUyxDQUFDLE9BQU8sQ0FBQyxzQkFBYSxDQUFDLENBQUM7SUFDNUUsTUFBTSxNQUFNLEdBQUcsTUFBTSxhQUFhLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFFaEYsSUFBSSxNQUFNLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDekIsSUFBSSxlQUFlLEdBQUcsRUFBRSxDQUFDO1FBQ3pCLE1BQU0scUJBQXFCLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDbEUsSUFBSSxDQUFDO1lBQ0gsTUFBTSxRQUFRLEdBQUcsTUFBTSxxQkFBcUIsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDcEYsSUFBSSxRQUFRLENBQUMsS0FBSztnQkFBRSxlQUFlLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztRQUN2RCxDQUFDO1FBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUNYLElBQUksQ0FBQztnQkFDSCxNQUFNLGlCQUFpQixHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUMxRCxNQUFNLElBQUksR0FBRyxNQUFNLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQ3hFLElBQUksSUFBSSxDQUFDLEtBQUs7b0JBQUUsZUFBZSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDL0MsQ0FBQztZQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQSxDQUFDO1FBQ2pCLENBQUM7UUFFRCxJQUFJLGVBQWUsRUFBRSxDQUFDO1lBQ3BCLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxNQUFNLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUM5RCxJQUFJLENBQUMsUUFBUSxJQUFJLFFBQVEsQ0FBQywyQkFBMkIsRUFBRSxDQUFDO2dCQUN0RCxNQUFNLFlBQVksR0FBRztvQkFDckIsYUFBYSxFQUFFLE1BQU0sQ0FBQyxhQUFhO29CQUNuQyxNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07b0JBQ3JCLGdCQUFnQixFQUFFLE1BQU0sQ0FBQyxFQUFFO29CQUMzQixlQUFlLEVBQUUsTUFBTSxDQUFDLGVBQWU7aUJBQ3hDLENBQUM7Z0JBQ0YsTUFBTSxRQUFRLEdBQUcsSUFBQSwwQkFBaUIsRUFBQyx5QkFBeUIsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFFNUUsTUFBTSx5QkFBeUIsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDMUUsTUFBTSx5QkFBeUIsQ0FBQyxtQkFBbUIsQ0FBQztvQkFDbEQsRUFBRSxFQUFFLGVBQWU7b0JBQ25CLE9BQU8sRUFBRSxPQUFPO29CQUNoQixRQUFRLEVBQUUseUJBQXlCO29CQUNuQyxPQUFPLEVBQUU7d0JBQ1AsT0FBTyxFQUFFLDBCQUEwQixNQUFNLENBQUMsYUFBYSxFQUFFO3dCQUN6RCxJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUk7cUJBQ3BCO29CQUNELElBQUksRUFBRTt3QkFDSixHQUFHLFlBQVk7d0JBQ2YsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJO3FCQUNwQjtpQkFDRixDQUFDLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFDQywyQ0FBMkM7SUFDM0MsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLE1BQU0sYUFBYSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzlELElBQUksUUFBUSxFQUFFLGtCQUFrQixJQUFJLFFBQVEsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUM1RCxJQUFJLENBQUM7WUFDSCxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzNDLE1BQU0sRUFBRSxnQkFBZ0IsRUFBRSxHQUFHLE1BQU0sTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUM7WUFDdkUsTUFBTSxJQUFJLEdBQUcsSUFBSSxnQkFBZ0IsQ0FBQztnQkFDaEMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxjQUFjO2dCQUNsQyxhQUFhLEVBQUUsUUFBUSxDQUFDLGtCQUFtQjtnQkFDM0MsYUFBYSxFQUFFLFFBQVEsQ0FBQyxrQkFBbUI7Z0JBQzNDLGVBQWUsRUFBRSxRQUFRLENBQUMsb0JBQXFCO2FBQ2hELEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFWCxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FBQztZQUN2QyxJQUFJLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUM5QixNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLGdCQUEwQixDQUFDLENBQUM7Z0JBQy9ELE1BQU0sQ0FBQyxJQUFJLENBQUMsaUNBQWlDLFFBQVEsQ0FBQyxnQkFBZ0Isd0JBQXdCLE1BQU0sQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUUzRyxzQkFBc0I7Z0JBQ3RCLE1BQU0sT0FBTyxHQUFHLEVBQUUsR0FBRyxRQUFRLEVBQUUsQ0FBQztnQkFDaEMsT0FBTyxPQUFPLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ2hDLE1BQU0sYUFBYSxDQUFDLG1CQUFtQixDQUFDLEVBQUUsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDaEYsQ0FBQztRQUNILENBQUM7UUFBQyxPQUFPLENBQU0sRUFBRSxDQUFDO1lBQ2hCLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLDJDQUEyQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM1RixDQUFDO0lBQ0gsQ0FBQztJQUVILE9BQU8sSUFBSSw0QkFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FDRixDQUFDO0FBRVcsUUFBQSx3QkFBd0IsR0FBRyxJQUFBLDhCQUFjLEVBQ3BELDZCQUE2QixFQUM3QixVQUFVLEtBQW9DO0lBQzVDLE1BQU0sYUFBYSxHQUFHLElBQUEsMERBQTRCLEVBQUM7UUFDakQsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGdCQUFnQjtRQUN4QyxNQUFNLEVBQUUsV0FBVztLQUNwQixDQUFDLENBQUM7SUFFSCxJQUFBLG9DQUE0QixFQUFDLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQztJQUUzRSxPQUFPLElBQUksZ0NBQWdCLENBQUM7UUFDMUIsWUFBWSxFQUFFLGFBQWE7S0FDNUIsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUNGLENBQUMifQ==