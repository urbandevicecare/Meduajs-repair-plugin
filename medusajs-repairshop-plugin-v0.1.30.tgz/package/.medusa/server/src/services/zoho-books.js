"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ZohoBooksService = void 0;
class ZohoBooksService {
    constructor(config, logger) {
        this.access_token = null;
        this.token_expires_at = 0;
        this.config = config;
        this.logger = logger;
    }
    async getAccessToken() {
        if (this.access_token && Date.now() < this.token_expires_at) {
            return this.access_token;
        }
        this.logger.info(`[Zoho Books] Refreshing access token...`);
        const params = new URLSearchParams();
        params.append("refresh_token", this.config.refresh_token);
        params.append("client_id", this.config.client_id);
        params.append("client_secret", this.config.client_secret);
        params.append("grant_type", "refresh_token");
        const response = await fetch("https://accounts.zoho.com/oauth/v2/token", {
            method: "POST",
            body: params,
        });
        const data = await response.json();
        if (!response.ok || data.error) {
            this.logger.error(`[Zoho Books] Failed to refresh token: ${JSON.stringify(data)}`);
            throw new Error("Zoho authentication failed");
        }
        this.access_token = data.access_token;
        this.token_expires_at = Date.now() + (data.expires_in - 300) * 1000;
        return this.access_token;
    }
    async request(method, endpoint, body, isBlob = false) {
        const token = await this.getAccessToken();
        const url = `https://www.zohoapis.com/books/v3${endpoint}${endpoint.includes("?") ? "&" : "?"}organization_id=${this.config.organization_id}`;
        const headers = {
            Authorization: `Zoho-oauthtoken ${token}`,
        };
        if (body) {
            headers["Content-Type"] = "application/json";
        }
        const res = await fetch(url, {
            method,
            headers,
            body: body ? JSON.stringify(body) : undefined,
        });
        if (isBlob) {
            if (!res.ok)
                throw new Error(`Zoho API Error: ${res.statusText}`);
            return await res.arrayBuffer();
        }
        const data = await res.json();
        if (!res.ok || data.code !== 0) {
            this.logger.error(`[Zoho Books] API Error: ${JSON.stringify(data)}`);
            throw new Error(`Zoho API Error: ${data.message || res.statusText}`);
        }
        return data;
    }
    async syncContact(customer) {
        const email = customer.email;
        const name = customer.first_name ? `${customer.first_name} ${customer.last_name || ""}`.trim() : email;
        // Check if contact exists by email
        if (email && email.includes("@")) {
            const searchRes = await this.request("GET", `/contacts?email=${encodeURIComponent(email)}`);
            if (searchRes.contacts && searchRes.contacts.length > 0) {
                return searchRes.contacts[0].contact_id;
            }
        }
        // Fallback: Check if contact exists by name
        if (name) {
            const searchNameRes = await this.request("GET", `/contacts?contact_name=${encodeURIComponent(name)}`);
            if (searchNameRes.contacts && searchNameRes.contacts.length > 0) {
                return searchNameRes.contacts[0].contact_id;
            }
        }
        // Create new contact
        const payload = {
            contact_name: name,
            company_name: name,
            contact_type: "customer",
            contact_persons: [{
                    first_name: customer.first_name || "Customer",
                    last_name: customer.last_name || "",
                    email: email,
                    phone: customer.phone || "",
                }]
        };
        const createRes = await this.request("POST", "/contacts", payload);
        return createRes.contact.contact_id;
    }
    formatLineItems(ticket) {
        const items = [];
        if (ticket.device?.parts_used && ticket.device.parts_used.length > 0) {
            for (const part of ticket.device.parts_used) {
                items.push({
                    name: part.name || "Part",
                    description: part.sku ? `SKU: ${part.sku}` : "",
                    rate: (Number(part.price || 0)).toFixed(2),
                    quantity: 1,
                    tax_id: ""
                });
            }
        }
        if (ticket.custom_parts && ticket.custom_parts.length > 0) {
            for (const cp of ticket.custom_parts) {
                items.push({
                    name: cp.name || "Custom Part / Service",
                    rate: (Number(cp.price || 0)).toFixed(2),
                    quantity: 1,
                    tax_id: ""
                });
            }
        }
        if (items.length === 0) {
            items.push({
                name: `Repair Ticket #${ticket.ticket_number}`,
                rate: (Number(ticket.total_estimate || 0)).toFixed(2),
                quantity: 1,
                tax_id: ""
            });
        }
        return items;
    }
    async createEstimate(contactId, ticket) {
        const payload = {
            customer_id: contactId,
            reference_number: `TKT-${ticket.ticket_number}`,
            line_items: this.formatLineItems(ticket),
            notes: "Generated from Medusa Repair Module",
            is_inclusive_tax: false
        };
        const res = await this.request("POST", "/estimates", payload);
        return res.estimate.estimate_id;
    }
    async deleteEstimate(estimateId) {
        await this.request("DELETE", `/estimates/${estimateId}`);
    }
    async createInvoice(contactId, ticket) {
        const payload = {
            customer_id: contactId,
            reference_number: `TKT-${ticket.ticket_number}`,
            line_items: this.formatLineItems(ticket),
            notes: "Generated from Medusa Repair Module",
            is_inclusive_tax: false
        };
        const res = await this.request("POST", "/invoices", payload);
        return res.invoice.invoice_id;
    }
    async deleteInvoice(invoiceId) {
        await this.request("DELETE", `/invoices/${invoiceId}`);
    }
    async getDocumentPdf(documentId, type) {
        const endpoint = type === "estimate" ? `/estimates/${documentId}` : `/invoices/${documentId}`;
        return await this.request("GET", `${endpoint}?accept=pdf`, undefined, true);
    }
    async registerPayment(invoiceId, amount, contactId, paymentMode) {
        const payload = {
            customer_id: contactId,
            payment_mode: paymentMode || "Stripe",
            amount: (amount).toFixed(2),
            date: new Date().toISOString().split('T')[0],
            invoices: [
                {
                    invoice_id: invoiceId,
                    amount_applied: (amount).toFixed(2)
                }
            ]
        };
        const res = await this.request("POST", "/customerpayments", payload);
        return res.payment.payment_id;
    }
    async getPaymentReceiptPdf(paymentId) {
        return await this.request("GET", `/customerpayments/${paymentId}?accept=pdf`, undefined, true);
    }
}
exports.ZohoBooksService = ZohoBooksService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiem9oby1ib29rcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zZXJ2aWNlcy96b2hvLWJvb2tzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQVNBLE1BQWEsZ0JBQWdCO0lBTTNCLFlBQVksTUFBa0IsRUFBRSxNQUFjO1FBSHRDLGlCQUFZLEdBQWtCLElBQUksQ0FBQztRQUNuQyxxQkFBZ0IsR0FBVyxDQUFDLENBQUM7UUFHbkMsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDckIsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7SUFDdkIsQ0FBQztJQUVPLEtBQUssQ0FBQyxjQUFjO1FBQzFCLElBQUksSUFBSSxDQUFDLFlBQVksSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDNUQsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBQzNCLENBQUM7UUFFRCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO1FBQzVELE1BQU0sTUFBTSxHQUFHLElBQUksZUFBZSxFQUFFLENBQUM7UUFDckMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUMxRCxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2xELE1BQU0sQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDMUQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFFN0MsTUFBTSxRQUFRLEdBQUcsTUFBTSxLQUFLLENBQUMsMENBQTBDLEVBQUU7WUFDdkUsTUFBTSxFQUFFLE1BQU07WUFDZCxJQUFJLEVBQUUsTUFBTTtTQUNiLENBQUMsQ0FBQztRQUVILE1BQU0sSUFBSSxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ25DLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUMvQixJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyx5Q0FBeUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDbkYsTUFBTSxJQUFJLEtBQUssQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO1FBQ2hELENBQUM7UUFFRCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDdEMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQ3BFLE9BQU8sSUFBSSxDQUFDLFlBQWEsQ0FBQztJQUM1QixDQUFDO0lBRU8sS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFjLEVBQUUsUUFBZ0IsRUFBRSxJQUFVLEVBQUUsU0FBa0IsS0FBSztRQUN6RixNQUFNLEtBQUssR0FBRyxNQUFNLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUMxQyxNQUFNLEdBQUcsR0FBRyxvQ0FBb0MsUUFBUSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxtQkFBbUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUU5SSxNQUFNLE9BQU8sR0FBMkI7WUFDdEMsYUFBYSxFQUFFLG1CQUFtQixLQUFLLEVBQUU7U0FDMUMsQ0FBQztRQUNGLElBQUksSUFBSSxFQUFFLENBQUM7WUFDVCxPQUFPLENBQUMsY0FBYyxDQUFDLEdBQUcsa0JBQWtCLENBQUM7UUFDL0MsQ0FBQztRQUVELE1BQU0sR0FBRyxHQUFHLE1BQU0sS0FBSyxDQUFDLEdBQUcsRUFBRTtZQUMzQixNQUFNO1lBQ04sT0FBTztZQUNQLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7U0FDOUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNYLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFBRSxNQUFNLElBQUksS0FBSyxDQUFDLG1CQUFtQixHQUFHLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQztZQUNsRSxPQUFPLE1BQU0sR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ2pDLENBQUM7UUFFRCxNQUFNLElBQUksR0FBRyxNQUFNLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQy9CLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLDJCQUEyQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNyRSxNQUFNLElBQUksS0FBSyxDQUFDLG1CQUFtQixJQUFJLENBQUMsT0FBTyxJQUFJLEdBQUcsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZFLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFRCxLQUFLLENBQUMsV0FBVyxDQUFDLFFBQWE7UUFDN0IsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztRQUM3QixNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxVQUFVLElBQUksUUFBUSxDQUFDLFNBQVMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBRXZHLG1DQUFtQztRQUNuQyxJQUFJLEtBQUssSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDakMsTUFBTSxTQUFTLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxtQkFBbUIsa0JBQWtCLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzVGLElBQUksU0FBUyxDQUFDLFFBQVEsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDeEQsT0FBTyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztZQUMxQyxDQUFDO1FBQ0gsQ0FBQztRQUVELDRDQUE0QztRQUM1QyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQ1QsTUFBTSxhQUFhLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSwwQkFBMEIsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3RHLElBQUksYUFBYSxDQUFDLFFBQVEsSUFBSSxhQUFhLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDaEUsT0FBTyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztZQUM5QyxDQUFDO1FBQ0gsQ0FBQztRQUVELHFCQUFxQjtRQUNyQixNQUFNLE9BQU8sR0FBRztZQUNkLFlBQVksRUFBRSxJQUFJO1lBQ2xCLFlBQVksRUFBRSxJQUFJO1lBQ2xCLFlBQVksRUFBRSxVQUFVO1lBQ3hCLGVBQWUsRUFBRSxDQUFDO29CQUNoQixVQUFVLEVBQUUsUUFBUSxDQUFDLFVBQVUsSUFBSSxVQUFVO29CQUM3QyxTQUFTLEVBQUUsUUFBUSxDQUFDLFNBQVMsSUFBSSxFQUFFO29CQUNuQyxLQUFLLEVBQUUsS0FBSztvQkFDWixLQUFLLEVBQUUsUUFBUSxDQUFDLEtBQUssSUFBSSxFQUFFO2lCQUM1QixDQUFDO1NBQ0gsQ0FBQztRQUVGLE1BQU0sU0FBUyxHQUFHLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ25FLE9BQU8sU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUM7SUFDdEMsQ0FBQztJQUVPLGVBQWUsQ0FBQyxNQUFXO1FBQ2pDLE1BQU0sS0FBSyxHQUFVLEVBQUUsQ0FBQztRQUN4QixJQUFJLE1BQU0sQ0FBQyxNQUFNLEVBQUUsVUFBVSxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNyRSxLQUFLLE1BQU0sSUFBSSxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQzVDLEtBQUssQ0FBQyxJQUFJLENBQUM7b0JBQ1QsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTTtvQkFDekIsV0FBVyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUMvQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7b0JBQzNDLFFBQVEsRUFBRSxDQUFDO29CQUNYLE1BQU0sRUFBRSxFQUFFO2lCQUNYLENBQUMsQ0FBQztZQUNMLENBQUM7UUFDSCxDQUFDO1FBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxJQUFJLE1BQU0sQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQzFELEtBQUssTUFBTSxFQUFFLElBQUksTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUNyQyxLQUFLLENBQUMsSUFBSSxDQUFDO29CQUNULElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxJQUFJLHVCQUF1QjtvQkFDeEMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO29CQUN6QyxRQUFRLEVBQUUsQ0FBQztvQkFDWCxNQUFNLEVBQUUsRUFBRTtpQkFDWCxDQUFDLENBQUM7WUFDTCxDQUFDO1FBQ0gsQ0FBQztRQUNELElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUN2QixLQUFLLENBQUMsSUFBSSxDQUFDO2dCQUNULElBQUksRUFBRSxrQkFBa0IsTUFBTSxDQUFDLGFBQWEsRUFBRTtnQkFDOUMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLElBQUksQ0FBQyxDQUFDLENBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUN0RCxRQUFRLEVBQUUsQ0FBQztnQkFDWCxNQUFNLEVBQUUsRUFBRTthQUNYLENBQUMsQ0FBQztRQUNMLENBQUM7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLFNBQWlCLEVBQUUsTUFBVztRQUNqRCxNQUFNLE9BQU8sR0FBRztZQUNkLFdBQVcsRUFBRSxTQUFTO1lBQ3RCLGdCQUFnQixFQUFFLE9BQU8sTUFBTSxDQUFDLGFBQWEsRUFBRTtZQUMvQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUM7WUFDeEMsS0FBSyxFQUFFLHFDQUFxQztZQUM1QyxnQkFBZ0IsRUFBRSxLQUFLO1NBQ3hCLENBQUM7UUFFRixNQUFNLEdBQUcsR0FBRyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztRQUM5RCxPQUFPLEdBQUcsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDO0lBQ2xDLENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLFVBQWtCO1FBQ3JDLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsY0FBYyxVQUFVLEVBQUUsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLFNBQWlCLEVBQUUsTUFBVztRQUNoRCxNQUFNLE9BQU8sR0FBRztZQUNkLFdBQVcsRUFBRSxTQUFTO1lBQ3RCLGdCQUFnQixFQUFFLE9BQU8sTUFBTSxDQUFDLGFBQWEsRUFBRTtZQUMvQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUM7WUFDeEMsS0FBSyxFQUFFLHFDQUFxQztZQUM1QyxnQkFBZ0IsRUFBRSxLQUFLO1NBQ3hCLENBQUM7UUFFRixNQUFNLEdBQUcsR0FBRyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUM3RCxPQUFPLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDO0lBQ2hDLENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLFNBQWlCO1FBQ25DLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsYUFBYSxTQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLFVBQWtCLEVBQUUsSUFBNEI7UUFDbkUsTUFBTSxRQUFRLEdBQUcsSUFBSSxLQUFLLFVBQVUsQ0FBQyxDQUFDLENBQUMsY0FBYyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsYUFBYSxVQUFVLEVBQUUsQ0FBQztRQUM5RixPQUFPLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBRyxRQUFRLGFBQWEsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDOUUsQ0FBQztJQUVELEtBQUssQ0FBQyxlQUFlLENBQUMsU0FBaUIsRUFBRSxNQUFjLEVBQUUsU0FBaUIsRUFBRSxXQUFtQjtRQUM3RixNQUFNLE9BQU8sR0FBRztZQUNkLFdBQVcsRUFBRSxTQUFTO1lBQ3RCLFlBQVksRUFBRSxXQUFXLElBQUksUUFBUTtZQUNyQyxNQUFNLEVBQUUsQ0FBQyxNQUFNLENBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQzVCLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDNUMsUUFBUSxFQUFFO2dCQUNSO29CQUNFLFVBQVUsRUFBRSxTQUFTO29CQUNyQixjQUFjLEVBQUUsQ0FBQyxNQUFNLENBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2lCQUNyQzthQUNGO1NBQ0YsQ0FBQztRQUNGLE1BQU0sR0FBRyxHQUFHLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsbUJBQW1CLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDckUsT0FBTyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztJQUNoQyxDQUFDO0lBRUQsS0FBSyxDQUFDLG9CQUFvQixDQUFDLFNBQWlCO1FBQzFDLE9BQU8sTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxxQkFBcUIsU0FBUyxhQUFhLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2pHLENBQUM7Q0FDRjtBQXZNRCw0Q0F1TUMifQ==