"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = globalNotificationHandler;
const utils_1 = require("@medusajs/framework/utils");
const repair_1 = require("../utils/templates/repair");
const repair_2 = require("../modules/repair");
async function globalNotificationHandler({ event, container, }) {
    const logger = container.resolve("logger");
    const eventName = event.name;
    const data = event.data;
    logger.info(`[Omni-Notify] 🟢 Triggered '${eventName}' subscriber.`);
    try {
        const notificationModuleService = container.resolve(utils_1.ModuleRegistrationName.NOTIFICATION, { allowUnregistered: true });
        if (!notificationModuleService) {
            logger.warn(`[Omni-Notify] ⚠️ Notification module not installed. Aborting.`);
            return;
        }
        const repairService = container.resolve(repair_2.REPAIR_MODULE);
        const [settings] = await repairService.listRepairSettings({});
        const ACTIVE_CHANNELS = [];
        if (!settings || settings.email_notifications_enabled)
            ACTIVE_CHANNELS.push("email");
        if (!settings || settings.sms_notifications_enabled)
            ACTIVE_CHANNELS.push("sms");
        if (!settings || settings.whatsapp_notifications_enabled)
            ACTIVE_CHANNELS.push("whatsapp");
        if (ACTIVE_CHANNELS.length === 0) {
            logger.info(`[Omni-Notify] All notification channels disabled in settings. Aborting.`);
            return;
        }
        let targetEmail = null;
        let targetPhone = null;
        let baseTemplateName = "";
        let notificationSubject = "";
        let emailHtmlContent = "";
        let textContent = "";
        let notificationData = {};
        const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
        let customerName = "Customer";
        // ---------------------------------------------------------
        // REPAIR EVENT FLOW
        // ---------------------------------------------------------
        if (eventName.startsWith("repair.")) {
            const ticketId = data.id || data.repair_ticket_id;
            if (!ticketId) {
                logger.warn(`[Omni-Notify] ⚠️ No ticket ID found in event data. Aborting.`);
                return;
            }
            logger.debug(`[Omni-Notify] Retrieving ticket data for ID: ${ticketId}...`);
            const { data: tickets } = await query.graph({
                entity: "repair_ticket",
                fields: ["*", "device.*"],
                filters: { id: ticketId },
            });
            if (!tickets || tickets.length === 0) {
                logger.warn(`[Omni-Notify] ⚠️ Repair ticket ${ticketId} not found`);
                return;
            }
            const ticket = tickets[0];
            const deviceModel = ticket.device?.model_name || "Device";
            const approvalUrl = ticket.approval_token
                ? `${process.env.STORE_URL || "http://localhost:3000"}/store/repairs/track?token=${ticket.approval_token}`
                : "";
            // Attempt to load customer details
            if (ticket.customer_id) {
                const customerModule = container.resolve(utils_1.ModuleRegistrationName.CUSTOMER, { allowUnregistered: true });
                if (customerModule) {
                    const customer = await customerModule.retrieveCustomer(ticket.customer_id);
                    if (customer) {
                        targetEmail = customer.email || null;
                        targetPhone = customer.phone || null;
                        customerName = customer.first_name || "Customer";
                        notificationData.customer = customer;
                    }
                }
            }
            let currencyCode = "usd";
            try {
                const regionModule = container.resolve(utils_1.Modules.REGION, { allowUnregistered: true });
                if (regionModule) {
                    const regions = await regionModule.listRegions({}, { take: 1 });
                    if (regions && regions.length > 0) {
                        currencyCode = regions[0].currency_code;
                    }
                }
            }
            catch (e) {
                // Fallback
            }
            let pdfUrl = "";
            if (ticket.approval_token) {
                if (ticket.status === "awaiting_approval")
                    pdfUrl = `${process.env.STORE_URL || "http://localhost:3000"}/store/repairs/token/${ticket.approval_token}/document?type=quote`;
                else if (ticket.payment_status === "captured" || ticket.payment_status === "paid")
                    pdfUrl = `${process.env.STORE_URL || "http://localhost:3000"}/store/repairs/token/${ticket.approval_token}/document?type=receipt`;
                else
                    pdfUrl = `${process.env.STORE_URL || "http://localhost:3000"}/store/repairs/token/${ticket.approval_token}/document?type=invoice`;
            }
            // Populate base data
            notificationData = {
                ...notificationData,
                ticket_number: ticket.ticket_number,
                device: deviceModel,
                status: data.status || ticket.status,
                approval_url: approvalUrl,
                pdf_url: pdfUrl,
                currency_code: currencyCode.toUpperCase(),
                total_estimate: Number(ticket.total_estimate?.value ?? ticket.total_estimate) / 100,
            };
            if (eventName === "repair.status_changed") {
                baseTemplateName = "repair-status";
                notificationSubject = `Repair Status Update: ${deviceModel} (#${ticket.ticket_number})`;
                // Fire admin notification too
                if (notificationModuleService) {
                    const adminTemplate = (0, repair_1.getRepairTemplate)("admin-repair-status", {
                        ...notificationData,
                        customer_name: customerName,
                    });
                    logger.debug(`[Omni-Notify] 🛡️ Queuing internal Admin Notification`);
                    notificationModuleService
                        .createNotifications({
                        to: "admin",
                        channel: "admin",
                        template: "admin-repair-status",
                        content: {
                            subject: `[Admin Alert] Status Changed: Ticket ${ticket.ticket_number}`,
                            html: adminTemplate.html,
                        },
                        data: { ...notificationData, body: adminTemplate.text },
                    })
                        .catch((e) => logger.warn(`[Omni-Notify] Admin notification failed: ${e.message}`));
                }
            }
            else if (eventName === "repair.ticket.compliance_requested") {
                baseTemplateName = "repair-compliance";
                notificationSubject = `Action Required: Repair Ticket #${ticket.ticket_number}`;
                notificationData.compliance_url = approvalUrl;
            }
            else if (eventName === "repair.customer_reminder") {
                baseTemplateName = "repair-reminder";
                notificationSubject = `Reminder: Repair Ticket #${ticket.ticket_number}`;
                let nudgeMessage = "Please review the status of your repair.";
                if (ticket.status === "awaiting_approval") {
                    nudgeMessage =
                        "We are waiting for your approval to proceed with the repair.";
                }
                else if (ticket.status === "completed" || ticket.status === "ready") {
                    nudgeMessage = "Your device is ready for pickup or payment.";
                }
                notificationData.nudge_message = nudgeMessage;
            }
            const template = (0, repair_1.getRepairTemplate)(baseTemplateName, notificationData);
            emailHtmlContent = template.html;
            textContent = template.text;
        }
        else {
            logger.warn(`[Omni-Notify] ⚠️ Unmapped event '${eventName}'. Aborting.`);
            return;
        }
        // ---------------------------------------------------------
        // MULTI-CHANNEL DISPATCH PREPARATION
        // ---------------------------------------------------------
        if (!targetEmail && !targetPhone) {
            logger.warn(`[Omni-Notify] ⚠️ No contact methods (email/phone) found for event ${eventName}. Aborting.`);
            return;
        }
        logger.debug(`[Omni-Notify] Preparing omni-channel dispatch for '${baseTemplateName}'...`);
        const dispatches = [];
        // 1. Queue Email
        if (ACTIVE_CHANNELS.includes("email") && targetEmail) {
            logger.debug(`[Omni-Notify] 📧 Queuing Email to ${targetEmail}`);
            dispatches.push(notificationModuleService.createNotifications({
                to: targetEmail,
                channel: "email",
                template: `${baseTemplateName}-email`,
                content: {
                    subject: notificationSubject,
                    html: emailHtmlContent,
                },
                data: notificationData,
            }));
        }
        // 2. Queue SMS
        if (ACTIVE_CHANNELS.includes("sms") && targetPhone) {
            logger.debug(`[Omni-Notify] 📱 Queuing SMS to ${targetPhone}`);
            dispatches.push(notificationModuleService.createNotifications({
                to: targetPhone,
                channel: "sms",
                template: `${baseTemplateName}-sms`,
                data: {
                    ...notificationData,
                    body: textContent,
                },
            }));
        }
        // 3. Queue WhatsApp
        if (ACTIVE_CHANNELS.includes("whatsapp") && targetPhone) {
            logger.debug(`[Omni-Notify] 💬 Queuing WhatsApp to ${targetPhone}`);
            dispatches.push(notificationModuleService.createNotifications({
                to: targetPhone,
                channel: "whatsapp",
                template: `${baseTemplateName}-whatsapp`,
                data: {
                    ...notificationData,
                    body: textContent,
                },
            }));
        }
        await Promise.allSettled(dispatches);
        logger.info(`[Omni-Notify] ✅ Successfully executed ${dispatches.length} notification(s) for '${eventName}'.`);
    }
    catch (error) {
        logger.error(`[Omni-Notify] ❌ Failed to process '${eventName}'`, error);
    }
}
exports.config = {
    event: [
        "repair.status_changed",
        "repair.ticket.compliance_requested",
        "repair.customer_reminder",
    ],
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibm90aWZpY2F0aW9ucy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zdWJzY3JpYmVycy9ub3RpZmljYXRpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQVVBLDRDQWlRQztBQTFRRCxxREFJbUM7QUFDbkMsc0RBQThEO0FBQzlELDhDQUFrRDtBQUduQyxLQUFLLFVBQVUseUJBQXlCLENBQUMsRUFDdEQsS0FBSyxFQUNMLFNBQVMsR0FDVztJQUNwQixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzNDLE1BQU0sU0FBUyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7SUFDN0IsTUFBTSxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztJQUV4QixNQUFNLENBQUMsSUFBSSxDQUFDLCtCQUErQixTQUFTLGVBQWUsQ0FBQyxDQUFDO0lBRXJFLElBQUksQ0FBQztRQUNILE1BQU0seUJBQXlCLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FDakQsOEJBQXNCLENBQUMsWUFBWSxFQUNuQyxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxDQUM1QixDQUFDO1FBQ0YsSUFBSSxDQUFDLHlCQUF5QixFQUFFLENBQUM7WUFDL0IsTUFBTSxDQUFDLElBQUksQ0FDVCwrREFBK0QsQ0FDaEUsQ0FBQztZQUNGLE9BQU87UUFDVCxDQUFDO1FBRUQsTUFBTSxhQUFhLEdBQXdCLFNBQVMsQ0FBQyxPQUFPLENBQUMsc0JBQWEsQ0FBQyxDQUFDO1FBQzVFLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxNQUFNLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUU5RCxNQUFNLGVBQWUsR0FBYSxFQUFFLENBQUM7UUFDckMsSUFBSSxDQUFDLFFBQVEsSUFBSSxRQUFRLENBQUMsMkJBQTJCO1lBQUUsZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNyRixJQUFJLENBQUMsUUFBUSxJQUFJLFFBQVEsQ0FBQyx5QkFBeUI7WUFBRSxlQUFlLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2pGLElBQUksQ0FBQyxRQUFRLElBQUksUUFBUSxDQUFDLDhCQUE4QjtZQUFFLGVBQWUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFM0YsSUFBSSxlQUFlLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ2pDLE1BQU0sQ0FBQyxJQUFJLENBQUMseUVBQXlFLENBQUMsQ0FBQztZQUN2RixPQUFPO1FBQ1QsQ0FBQztRQUVELElBQUksV0FBVyxHQUFrQixJQUFJLENBQUM7UUFDdEMsSUFBSSxXQUFXLEdBQWtCLElBQUksQ0FBQztRQUV0QyxJQUFJLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztRQUMxQixJQUFJLG1CQUFtQixHQUFHLEVBQUUsQ0FBQztRQUM3QixJQUFJLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztRQUMxQixJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7UUFDckIsSUFBSSxnQkFBZ0IsR0FBd0IsRUFBRSxDQUFDO1FBQy9DLE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFakUsSUFBSSxZQUFZLEdBQUcsVUFBVSxDQUFDO1FBRTlCLDREQUE0RDtRQUM1RCxvQkFBb0I7UUFDcEIsNERBQTREO1FBQzVELElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO1lBQ3BDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxFQUFFLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDO1lBQ2xELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDZCxNQUFNLENBQUMsSUFBSSxDQUNULDhEQUE4RCxDQUMvRCxDQUFDO2dCQUNGLE9BQU87WUFDVCxDQUFDO1lBRUQsTUFBTSxDQUFDLEtBQUssQ0FDVixnREFBZ0QsUUFBUSxLQUFLLENBQzlELENBQUM7WUFDRixNQUFNLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDMUMsTUFBTSxFQUFFLGVBQWU7Z0JBQ3ZCLE1BQU0sRUFBRSxDQUFDLEdBQUcsRUFBRSxVQUFVLENBQUM7Z0JBQ3pCLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUU7YUFDMUIsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUNyQyxNQUFNLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxRQUFRLFlBQVksQ0FBQyxDQUFDO2dCQUNwRSxPQUFPO1lBQ1QsQ0FBQztZQUVELE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxQixNQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLFVBQVUsSUFBSSxRQUFRLENBQUM7WUFDMUQsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLGNBQWM7Z0JBQ3ZDLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxJQUFJLHVCQUF1Qiw4QkFBOEIsTUFBTSxDQUFDLGNBQWMsRUFBRTtnQkFDMUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUVQLG1DQUFtQztZQUNuQyxJQUFJLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDdkIsTUFBTSxjQUFjLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FDdEMsOEJBQXNCLENBQUMsUUFBUSxFQUMvQixFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxDQUM1QixDQUFDO2dCQUNGLElBQUksY0FBYyxFQUFFLENBQUM7b0JBQ25CLE1BQU0sUUFBUSxHQUFHLE1BQU0sY0FBYyxDQUFDLGdCQUFnQixDQUNwRCxNQUFNLENBQUMsV0FBVyxDQUNuQixDQUFDO29CQUNGLElBQUksUUFBUSxFQUFFLENBQUM7d0JBQ2IsV0FBVyxHQUFHLFFBQVEsQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDO3dCQUNyQyxXQUFXLEdBQUcsUUFBUSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUM7d0JBQ3JDLFlBQVksR0FBRyxRQUFRLENBQUMsVUFBVSxJQUFJLFVBQVUsQ0FBQzt3QkFDakQsZ0JBQWdCLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztvQkFDdkMsQ0FBQztnQkFDSCxDQUFDO1lBQ0gsQ0FBQztZQUVELElBQUksWUFBWSxHQUFHLEtBQUssQ0FBQztZQUN6QixJQUFJLENBQUM7Z0JBQ0gsTUFBTSxZQUFZLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDcEYsSUFBSSxZQUFZLEVBQUUsQ0FBQztvQkFDakIsTUFBTSxPQUFPLEdBQUcsTUFBTSxZQUFZLENBQUMsV0FBVyxDQUFDLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUNoRSxJQUFJLE9BQU8sSUFBSSxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUNsQyxZQUFZLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQztvQkFDMUMsQ0FBQztnQkFDSCxDQUFDO1lBQ0gsQ0FBQztZQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0JBQ1gsV0FBVztZQUNiLENBQUM7WUFFRCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7WUFDaEIsSUFBSSxNQUFNLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQzFCLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxtQkFBbUI7b0JBQUUsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLElBQUksdUJBQXVCLHdCQUF3QixNQUFNLENBQUMsY0FBYyxzQkFBc0IsQ0FBQztxQkFDdEssSUFBSSxNQUFNLENBQUMsY0FBYyxLQUFLLFVBQVUsSUFBSSxNQUFNLENBQUMsY0FBYyxLQUFLLE1BQU07b0JBQUUsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLElBQUksdUJBQXVCLHdCQUF3QixNQUFNLENBQUMsY0FBYyx3QkFBd0IsQ0FBQzs7b0JBQ2hOLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxJQUFJLHVCQUF1Qix3QkFBd0IsTUFBTSxDQUFDLGNBQWMsd0JBQXdCLENBQUM7WUFDekksQ0FBQztZQUVELHFCQUFxQjtZQUNyQixnQkFBZ0IsR0FBRztnQkFDakIsR0FBRyxnQkFBZ0I7Z0JBQ25CLGFBQWEsRUFBRSxNQUFNLENBQUMsYUFBYTtnQkFDbkMsTUFBTSxFQUFFLFdBQVc7Z0JBQ25CLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxJQUFJLE1BQU0sQ0FBQyxNQUFNO2dCQUNwQyxZQUFZLEVBQUUsV0FBVztnQkFDekIsT0FBTyxFQUFFLE1BQU07Z0JBQ2YsYUFBYSxFQUFFLFlBQVksQ0FBQyxXQUFXLEVBQUU7Z0JBQ3pDLGNBQWMsRUFDWixNQUFNLENBQ0gsTUFBTSxDQUFDLGNBQXNCLEVBQUUsS0FBSyxJQUFJLE1BQU0sQ0FBQyxjQUFjLENBQy9ELEdBQUcsR0FBRzthQUNWLENBQUM7WUFFRixJQUFJLFNBQVMsS0FBSyx1QkFBdUIsRUFBRSxDQUFDO2dCQUMxQyxnQkFBZ0IsR0FBRyxlQUFlLENBQUM7Z0JBQ25DLG1CQUFtQixHQUFHLHlCQUF5QixXQUFXLE1BQU0sTUFBTSxDQUFDLGFBQWEsR0FBRyxDQUFDO2dCQUV4Riw4QkFBOEI7Z0JBQzlCLElBQUkseUJBQXlCLEVBQUUsQ0FBQztvQkFDOUIsTUFBTSxhQUFhLEdBQUcsSUFBQSwwQkFBaUIsRUFBQyxxQkFBcUIsRUFBRTt3QkFDN0QsR0FBRyxnQkFBZ0I7d0JBQ25CLGFBQWEsRUFBRSxZQUFZO3FCQUM1QixDQUFDLENBQUM7b0JBQ0gsTUFBTSxDQUFDLEtBQUssQ0FBQyx1REFBdUQsQ0FBQyxDQUFDO29CQUN0RSx5QkFBeUI7eUJBQ3RCLG1CQUFtQixDQUFDO3dCQUNuQixFQUFFLEVBQUUsT0FBTzt3QkFDWCxPQUFPLEVBQUUsT0FBTzt3QkFDaEIsUUFBUSxFQUFFLHFCQUFxQjt3QkFDL0IsT0FBTyxFQUFFOzRCQUNQLE9BQU8sRUFBRSx3Q0FBd0MsTUFBTSxDQUFDLGFBQWEsRUFBRTs0QkFDdkUsSUFBSSxFQUFFLGFBQWEsQ0FBQyxJQUFJO3lCQUN6Qjt3QkFDRCxJQUFJLEVBQUUsRUFBRSxHQUFHLGdCQUFnQixFQUFFLElBQUksRUFBRSxhQUFhLENBQUMsSUFBSSxFQUFFO3FCQUN4RCxDQUFDO3lCQUNELEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQ1gsTUFBTSxDQUFDLElBQUksQ0FDVCw0Q0FBNEMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUN4RCxDQUNGLENBQUM7Z0JBQ04sQ0FBQztZQUNILENBQUM7aUJBQU0sSUFBSSxTQUFTLEtBQUssb0NBQW9DLEVBQUUsQ0FBQztnQkFDOUQsZ0JBQWdCLEdBQUcsbUJBQW1CLENBQUM7Z0JBQ3ZDLG1CQUFtQixHQUFHLG1DQUFtQyxNQUFNLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ2hGLGdCQUFnQixDQUFDLGNBQWMsR0FBRyxXQUFXLENBQUM7WUFDaEQsQ0FBQztpQkFBTSxJQUFJLFNBQVMsS0FBSywwQkFBMEIsRUFBRSxDQUFDO2dCQUNwRCxnQkFBZ0IsR0FBRyxpQkFBaUIsQ0FBQztnQkFDckMsbUJBQW1CLEdBQUcsNEJBQTRCLE1BQU0sQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDekUsSUFBSSxZQUFZLEdBQUcsMENBQTBDLENBQUM7Z0JBQzlELElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxtQkFBbUIsRUFBRSxDQUFDO29CQUMxQyxZQUFZO3dCQUNWLDhEQUE4RCxDQUFDO2dCQUNuRSxDQUFDO3FCQUFNLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxXQUFXLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxPQUFPLEVBQUUsQ0FBQztvQkFDdEUsWUFBWSxHQUFHLDZDQUE2QyxDQUFDO2dCQUMvRCxDQUFDO2dCQUNELGdCQUFnQixDQUFDLGFBQWEsR0FBRyxZQUFZLENBQUM7WUFDaEQsQ0FBQztZQUVELE1BQU0sUUFBUSxHQUFHLElBQUEsMEJBQWlCLEVBQUMsZ0JBQWdCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztZQUN2RSxnQkFBZ0IsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO1lBQ2pDLFdBQVcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO1FBQzlCLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxDQUFDLElBQUksQ0FBQyxvQ0FBb0MsU0FBUyxjQUFjLENBQUMsQ0FBQztZQUN6RSxPQUFPO1FBQ1QsQ0FBQztRQUVELDREQUE0RDtRQUM1RCxxQ0FBcUM7UUFDckMsNERBQTREO1FBQzVELElBQUksQ0FBQyxXQUFXLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNqQyxNQUFNLENBQUMsSUFBSSxDQUNULHFFQUFxRSxTQUFTLGFBQWEsQ0FDNUYsQ0FBQztZQUNGLE9BQU87UUFDVCxDQUFDO1FBRUQsTUFBTSxDQUFDLEtBQUssQ0FDVixzREFBc0QsZ0JBQWdCLE1BQU0sQ0FDN0UsQ0FBQztRQUNGLE1BQU0sVUFBVSxHQUFtQixFQUFFLENBQUM7UUFFdEMsaUJBQWlCO1FBQ2pCLElBQUksZUFBZSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxXQUFXLEVBQUUsQ0FBQztZQUNyRCxNQUFNLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1lBQ2pFLFVBQVUsQ0FBQyxJQUFJLENBQ2IseUJBQXlCLENBQUMsbUJBQW1CLENBQUM7Z0JBQzVDLEVBQUUsRUFBRSxXQUFXO2dCQUNmLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixRQUFRLEVBQUUsR0FBRyxnQkFBZ0IsUUFBUTtnQkFDckMsT0FBTyxFQUFFO29CQUNQLE9BQU8sRUFBRSxtQkFBbUI7b0JBQzVCLElBQUksRUFBRSxnQkFBZ0I7aUJBQ3ZCO2dCQUNELElBQUksRUFBRSxnQkFBZ0I7YUFDdkIsQ0FBQyxDQUNILENBQUM7UUFDSixDQUFDO1FBRUQsZUFBZTtRQUNmLElBQUksZUFBZSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxXQUFXLEVBQUUsQ0FBQztZQUNuRCxNQUFNLENBQUMsS0FBSyxDQUFDLG1DQUFtQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1lBQy9ELFVBQVUsQ0FBQyxJQUFJLENBQ2IseUJBQXlCLENBQUMsbUJBQW1CLENBQUM7Z0JBQzVDLEVBQUUsRUFBRSxXQUFXO2dCQUNmLE9BQU8sRUFBRSxLQUFLO2dCQUNkLFFBQVEsRUFBRSxHQUFHLGdCQUFnQixNQUFNO2dCQUNuQyxJQUFJLEVBQUU7b0JBQ0osR0FBRyxnQkFBZ0I7b0JBQ25CLElBQUksRUFBRSxXQUFXO2lCQUNsQjthQUNGLENBQUMsQ0FDSCxDQUFDO1FBQ0osQ0FBQztRQUVELG9CQUFvQjtRQUNwQixJQUFJLGVBQWUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLElBQUksV0FBVyxFQUFFLENBQUM7WUFDeEQsTUFBTSxDQUFDLEtBQUssQ0FBQyx3Q0FBd0MsV0FBVyxFQUFFLENBQUMsQ0FBQztZQUNwRSxVQUFVLENBQUMsSUFBSSxDQUNiLHlCQUF5QixDQUFDLG1CQUFtQixDQUFDO2dCQUM1QyxFQUFFLEVBQUUsV0FBVztnQkFDZixPQUFPLEVBQUUsVUFBVTtnQkFDbkIsUUFBUSxFQUFFLEdBQUcsZ0JBQWdCLFdBQVc7Z0JBQ3hDLElBQUksRUFBRTtvQkFDSixHQUFHLGdCQUFnQjtvQkFDbkIsSUFBSSxFQUFFLFdBQVc7aUJBQ2xCO2FBQ0YsQ0FBQyxDQUNILENBQUM7UUFDSixDQUFDO1FBRUQsTUFBTSxPQUFPLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLE1BQU0sQ0FBQyxJQUFJLENBQ1QseUNBQXlDLFVBQVUsQ0FBQyxNQUFNLHlCQUF5QixTQUFTLElBQUksQ0FDakcsQ0FBQztJQUNKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsTUFBTSxDQUFDLEtBQUssQ0FBQyxzQ0FBc0MsU0FBUyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUUsQ0FBQztBQUNILENBQUM7QUFFWSxRQUFBLE1BQU0sR0FBcUI7SUFDdEMsS0FBSyxFQUFFO1FBQ0wsdUJBQXVCO1FBQ3ZCLG9DQUFvQztRQUNwQywwQkFBMEI7S0FDM0I7Q0FDRixDQUFDIn0=