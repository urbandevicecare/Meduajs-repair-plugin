"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const add_repair_parts_workflow_1 = require("../../../../../workflows/add-repair-parts-workflow");
// POST /admin/repairs/:id/parts - Add parts to repair ticket
async function POST(req, res) {
    const { variant_ids } = req.validatedBody;
    const { result } = await (0, add_repair_parts_workflow_1.addRepairPartsWorkflow)(req.scope).run({
        input: {
            repair_ticket_id: req.params.id,
            variant_ids,
        },
    });
    res.json(result);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3JlcGFpcnMvW2lkXS9wYXJ0cy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUlBLG9CQWdCQztBQW5CRCxrR0FBNEY7QUFFNUYsNkRBQTZEO0FBQ3RELEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBRUUsRUFDRixHQUFtQjtJQUVuQixNQUFNLEVBQUUsV0FBVyxFQUFFLEdBQUcsR0FBRyxDQUFDLGFBQWEsQ0FBQztJQUUxQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFBLGtEQUFzQixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDN0QsS0FBSyxFQUFFO1lBQ0wsZ0JBQWdCLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQy9CLFdBQVc7U0FDWjtLQUNGLENBQUMsQ0FBQztJQUVILEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbkIsQ0FBQyJ9